from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
import ast
import os
import base64
import datetime

flag = open("flag.txt", "r").read().strip()
key = os.urandom(16)

next_user_id = 1
current_id = 0

ALG_AES_CBC = 1
ALG_AES_GCM = 2
CHEQUE_EXPIRING_EN_SEC = 30

users = {}

def encrypt_GCM(data, iv):
    encryptor = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend()).encryptor()
    return encryptor.update(data) + encryptor.finalize(), encryptor.tag

def decrypt_GCM(data, iv, tag):
    decryptor = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend()).decryptor()
    return decryptor.update(data) + decryptor.finalize_with_tag(tag)

def encrypt_CBC(data, iv):
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    return encryptor.update(padded_data) + encryptor.finalize()

def decrypt_CBC(data, iv):
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_data = decryptor.update(data) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(padded_data) + unpadder.finalize()

def encrypt_cheque(cheque):
    cheque = str(cheque).encode()
    alg = users[current_id]["alg"]
    token = None
    if alg == ALG_AES_CBC:
        iv = os.urandom(16)
        enc_cheque = encrypt_CBC(cheque, iv)
        token = {
                    "enc_cheque": enc_cheque.hex(),
                    "iv": iv.hex()
                }
    elif alg == ALG_AES_GCM:
        iv = os.urandom(12)
        enc_cheque, tag = encrypt_GCM(cheque, iv)
        token = {
                    "enc_cheque": enc_cheque.hex(),
                    "iv": iv.hex(),
                    "tag": tag.hex()
                }
    token["alg"] = alg
    return base64.b64encode(str(token).encode()).decode()

def decrypt_cheque(token):
    token = base64.b64decode(token).decode()
    token = ast.literal_eval(token)
    if not isinstance(token, dict):
        print("bad cheque")
        return None
    alg = token["alg"]
    iv = bytes.fromhex(token["iv"])
    enc_cheque = bytes.fromhex(token["enc_cheque"])
    cheque = None
    if alg == ALG_AES_CBC:
        cheque = decrypt_CBC(enc_cheque, iv)
    elif alg == ALG_AES_GCM:
        tag = bytes.fromhex(token["tag"])
        cheque = decrypt_GCM(enc_cheque, iv, tag)
    else:
        return None
    cheque = ast.literal_eval(cheque.decode())
    return cheque

def add_account(username, password, balance):
    global next_user_id

    users[next_user_id] = {
        "username": username,
        "password": password,
        "balance": balance,
        "alg": ALG_AES_CBC
    }
    next_user_id += 1

def login():
    global next_user_id, current_id
    username = str(input("username: "))
    password = str(input("password: "))
    for user_id in users:
        if users[user_id]["username"] == username \
        and users[user_id]["password"] == password:
            current_id = user_id
            print(f"Welcome {users[current_id]['username']}!")
            return
    print("Invalid Credentials.")

def register(balance=0):
    username = input("username: ")
    password = input("password: ")

    if len(username) < 3 or len(username) > 20 \
        or not username.isalnum() or len(password) < 3 \
        or len(password) > 20 or not password.isprintable():
        print("Invalid input.")
        return
    add_account(username, password, balance)

def make_cheque():
    if users[current_id]["balance"] >= 1000:
        print(f"this is your golden cheque Mr/Mrs. {users[current_id]['username']}: {flag}")
    amount = int(input("amount: "))
    receiver_id = int(input("receiver id: "))
    timestamp = int(datetime.datetime.now().timestamp())
    cheque_token = {"timestamp": timestamp, "sender_id": current_id, "receiver_id": receiver_id, "amount": amount}
    print(f"Cheque token: {encrypt_cheque(cheque_token)}")

def validate_cheque(cheque):
    sender_id, receiver_id = cheque["sender_id"], cheque["receiver_id"]
    amount = cheque["amount"]

    timestamp = cheque["timestamp"]
    current_timestamp = int(datetime.datetime.now().timestamp())

    sender = users[sender_id]
    if (sender_id == receiver_id) \
        or sender_id not in users \
        or receiver_id != current_id \
        or amount < 1 \
        or sender["balance"] < amount \
        or current_timestamp - timestamp > CHEQUE_EXPIRING_EN_SEC:
        return None, None, True
    return sender_id, amount, False 

def cash_cheque():
    token = str(input("Cheque token: "))
    cheque = decrypt_cheque(token)
    if not isinstance(cheque , dict):
        return print("invalid cheque")

    sender_id, amount, error = validate_cheque(cheque)
    if error:
        return print("Invalid cheque!")
    sender = users[sender_id]
    sender["balance"] = sender["balance"] - amount
    users[current_id]["balance"] += amount
    print("Cashing cheque successfully")

def logout():
    global current_id
    current_id = 0

def update_enc_alg():
    print(f"current alg is {'AES-CBC' if users[current_id]['alg'] == ALG_AES_CBC else 'AES-GCM'}")
    print("1 -> AES-CBC\n2 -> AES-GCM")
    alg_num = int(input("> "))
    if alg_num not in {ALG_AES_CBC, ALG_AES_GCM}:
        print("invalid input")
        return
    users[current_id]["alg"] = alg_num


def print_user_info():
    global current_id
    print(f"Hi {users[current_id]['username']}, your balance is {users[current_id]['balance']}\nYour Account ID: {current_id}")

BANNER = r"""
 ________  ___      ___ ________     _____     
|\   __  \|\  \    /  /|\   ___  \  / __  \    
\ \  \|\  \ \  \  /  / | \  \\ \  \|\/_|\  \   
 \ \  \\\  \ \  \/  / / \ \  \\ \  \|/ \ \  \  
  \ \  \\\  \ \    / /   \ \  \\ \  \   \ \  \ 
   \ \_______\ \__/ /     \ \__\\ \__\   \ \__\
    \|_______|\|__|/       \|__| \|__|    \|__|
"""

def print_options_1():
    print("""1- Login
2- Register
3- Exit""")

def print_options_2():
    print("""1- Make a cheque
2- Cash a cheque
3- update encryption spec
4- Logout
5- Exit""")

if __name__ == "__main__":
    print(BANNER)
    add_account("siraj_dine", flag, 1337)
    while True:
        try:
            if current_id in users:
                print_user_info()
                print_options_2()
                option = int(input("> "))
                if option == 1:
                    make_cheque()
                elif option == 2:
                    cash_cheque()
                elif option == 3:
                    update_enc_alg()
                elif option == 4:
                    logout()
                elif option == 5:
                    exit()
            else:
                print_options_1()
                option = int(input("> "))
                if option == 1:
                    login()
                elif option == 2:
                    register()
                elif option == 3:
                    exit()
        except Exception as e:
            print(f"Error: {e}")


#ifndef BURP_H
#define BURP_H

// includes
#include <efi/efi.h>
#include <efi/efilib.h>
#include <efi/efiprot.h>
#include <stdbool.h>

// io.c

#define SCR_BUFF_SIZE 0xfa0

typedef struct _syscall_table {
    EFI_STALL		sleep;
    EFI_RESET_SYSTEM	exit;
}_syscall_table;


typedef struct _io{
    CHAR16	scr_buff[SCR_BUFF_SIZE];
    int16_t	size;	
    uint64_t	init;
    CHAR16	*scr_buff_ptr;
}_io;

void fgets(CHAR16 *buffer, uint64_t size);
void puts(CHAR16 *s);
void flush(_io *io);
void putchar(CHAR16 c);
void print(CHAR16 *s);
int16_t strcmp(CHAR16 *a, CHAR16 *b);
void rmchar();

extern _io general_io;
extern bool gen_io_init;
extern EFI_SYSTEM_TABLE *sys_table;

// utils.c
void uint_to_str(UINTN value, CHAR16 *buffer);
uint64_t strlen(CHAR16 *s);
void *memset(void *s, char c, uint64_t n);
void strlcpy(CHAR16 *dst, CHAR16 *src, uint64_t n);
void *memcpy(void *dst, void *src, uint64_t n);

// log.c
typedef enum LOG_LEVEL {
    WARN,
    INFO,
    DBG,
    ERROR,
    SUCCESS
} LOG_LEVEL;

#define DBG_MODE
void logx(EFI_SYSTEM_TABLE*sys_table, CHAR16 *msg, LOG_LEVEL lvl);
VOID ptr_to_hex(VOID *ptr, CHAR16 *out);

// user management
typedef struct user {
    CHAR16 *username;
    CHAR16 *password;
} user;

typedef struct inp_user {
    CHAR16 username[0x100];
    CHAR16 password[0x100];
} inp_user;

extern user root;


EFI_STATUS EFIAPI efi_main(EFI_HANDLE ImageHandler, EFI_SYSTEM_TABLE *SystemTable);

#endif

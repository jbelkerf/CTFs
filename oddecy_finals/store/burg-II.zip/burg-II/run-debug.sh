#!/bin/sh

TMP=$(mktemp)

cp burg_hda.bin $TMP
stty -echo

qemu-system-x86_64 \
    -s \
    -S \
    -drive format=raw,file=$TMP,if=ide\
    -bios deps/UEFI-GPT-image-creator/bios64.bin\
    -m 256M \
    -vga std \
    -name BURG \
    -machine q35 \
    -serial stdio \
    -nographic \
    -monitor none \
    -net none

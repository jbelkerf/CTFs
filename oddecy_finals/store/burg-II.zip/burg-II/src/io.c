#include "../inc/burg.h"

// output
bool gen_io_init = false;
_io general_io = {
    .size = 0,
    .scr_buff_ptr = NULL,
    .init = false
};

void init_io(_io *io){
    io->scr_buff_ptr = io->scr_buff;
    io->init = true;
}

// the backspace of io
void rmchar(void){
    if (general_io.init == false)
	init_io(&general_io);
    
    // before outputing to screen we check if we underflow the scr_buff
    if (general_io.size - 1 < 0)
	return;
    
    *(general_io.scr_buff_ptr - 1) = L'\0';
    general_io.scr_buff_ptr--;
    general_io.size--;
    sys_table->ConOut->ClearScreen(sys_table->ConOut);
    sys_table->ConOut->OutputString(sys_table->ConOut, general_io.scr_buff);

}


void putchar(CHAR16 c){
    CHAR16 outp[2] = {0,0};
    if (general_io.init == false)
	init_io(&general_io);
    
    // before outputing to screen we check if we overflow the scr_buff
    if (general_io.size + 1 >= SCR_BUFF_SIZE)
	flush(&general_io);   
    
    *(general_io.scr_buff_ptr) = c;
    general_io.scr_buff_ptr++;
    general_io.size++;
    sys_table->ConOut->OutputString(sys_table->ConOut, (general_io.scr_buff_ptr - 1));
}

void flush(_io *io){
    // flushing the console
    sys_table->ConOut->Reset(sys_table->ConOut, TRUE);
    sys_table->ConOut->OutputString(sys_table->ConOut, io->scr_buff);
    memset(io->scr_buff, 0, (SCR_BUFF_SIZE * sizeof(CHAR16)));
    io->scr_buff_ptr = io->scr_buff;
    io->size = 0;

}

void print(CHAR16 *s){
    // filling up the screen_buffer
    uint64_t sbytes = strlen(s);
    
    if (general_io.init == false)
	init_io(&general_io);
    
    // before outputing to screen we check if we overflow the scr_buff
    if (general_io.size + sbytes > SCR_BUFF_SIZE)
	flush(&general_io);

    strlcpy(general_io.scr_buff_ptr, s, sbytes);

    general_io.size += sbytes;
    general_io.scr_buff_ptr += sbytes;

    sys_table->ConOut->OutputString(sys_table->ConOut, general_io.scr_buff + (general_io.size - sbytes));
}

void puts(CHAR16 *s){
    uint64_t sbytes = strlen(s);
    
    if (general_io.init == false)
	init_io(&general_io);
    
    // before outputing to screen we check if we overflow the scr_buff
    if (general_io.size + sbytes > SCR_BUFF_SIZE)
	flush(&general_io);

    strlcpy(general_io.scr_buff_ptr, s, sbytes);

    general_io.size += sbytes;
    general_io.scr_buff_ptr += sbytes;

    // adding the newline
    *(general_io.scr_buff_ptr) = L'\n';
    general_io.scr_buff_ptr++;
    general_io.size++;
    sbytes++;

    sys_table->ConOut->OutputString(sys_table->ConOut, general_io.scr_buff + (general_io.size - sbytes));
}

// input

void fgets(CHAR16 *buffer, uint64_t size){
    EFI_INPUT_KEY key; 
    int64_t i = 0;

    memset(buffer, 0, size * sizeof(CHAR16));
    while (i < size){
	while (sys_table->ConIn->ReadKeyStroke(sys_table->ConIn, &key) != EFI_SUCCESS);

	// backspaces are working
	if (key.ScanCode == 8 && key.UnicodeChar == 0){
	    if (i > 0){
		rmchar();
		i--;
		buffer[i] = L'\x00';
	    }
	    continue;
	}

	if (key.UnicodeChar == 13 || key.UnicodeChar == 10){
	    print(L"\r\n");
	    buffer[i] = L'\x00';
	    return;
	}

	if (key.ScanCode == 0){
	    if (key.UnicodeChar < 7){
		buffer[i] = L'\x00';
	    } else {
		buffer[i] = key.UnicodeChar;
	    }
	    putchar(buffer[i]);
	    i++;
	}
    }
}

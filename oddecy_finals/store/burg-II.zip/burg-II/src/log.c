#include "../inc/burg.h"

// print colored str
void pcol_str(EFI_SYSTEM_TABLE* sys_table, CHAR16 *msg, int fg, int bg){
    sys_table->ConOut->SetAttribute(sys_table->ConOut, EFI_TEXT_ATTR(fg, bg));
    sys_table->ConOut->OutputString(sys_table->ConOut, msg);
    // restoring back
    sys_table->ConOut->SetAttribute(sys_table->ConOut, EFI_TEXT_ATTR(EFI_LIGHTGRAY, EFI_BLACK));
}

void print_decorator(EFI_SYSTEM_TABLE*sys_table, CHAR16 *dec, int fg, int bg){
    sys_table->ConOut->OutputString(sys_table->ConOut, L"[");
    pcol_str(sys_table, dec, fg, bg);
    sys_table->ConOut->OutputString(sys_table->ConOut, L"] - ");
}

void logx(EFI_SYSTEM_TABLE*sys_table, CHAR16 *msg, LOG_LEVEL lvl){
    if (lvl == WARN){
	print_decorator(sys_table, L"!", EFI_YELLOW, EFI_WHITE);
    } else if (lvl == INFO){
	print_decorator(sys_table, L"*", EFI_BLUE, EFI_BLACK);
    } else if (lvl == SUCCESS){
	print_decorator(sys_table, L"+", EFI_GREEN, EFI_BLACK);
    } else if (lvl == DBG){
#ifdef DBG_MODE
	print_decorator(sys_table, L"DBG", EFI_BLUE, EFI_BLACK);
#endif
    } else if (lvl == ERROR){
	// Attention this will exit
	print_decorator(sys_table, L"ERROR", EFI_BLUE, EFI_BLACK);
	sys_table->RuntimeServices->ResetSystem(EfiResetShutdown, EFI_ABORTED, 0, NULL);
    }

    sys_table->ConOut->OutputString(sys_table->ConOut, msg);
    sys_table->ConOut->OutputString(sys_table->ConOut, L"\r\n");
}

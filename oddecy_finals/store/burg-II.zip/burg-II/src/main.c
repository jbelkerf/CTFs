#include "../inc/burg.h"

_syscall_table syscalltable;

user root = {
    .username= L"root",
    .password = L"YouLieCheatAndStealYouNeverTolerate"
};


void init(){
    syscalltable.sleep = sys_table->BootServices->Stall;
    syscalltable.exit = sys_table->RuntimeServices->ResetSystem;
}

bool login(){
    inp_user user;
    memset(&user, 0, sizeof(inp_user));
    print(L"Username: ");
    fgets(user.username, 0xff);
    print(L"Password: ");
    fgets(user.password, 0xff);

    if (strcmp(root.username, user.username) == 0 &&
	    strcmp(root.password, user.password) == 0)
	return (true);

    return (false);
}

VOID shell(){
    CHAR16 scmd[0x100];
    while (true){
	memset(scmd, 0, 0x100 * sizeof(CHAR16));
	fgets(scmd, 0xff);
	puts(scmd);
	if (strcmp(scmd, L"exit") == 0){
	    return;
	}
    }
}

EFI_SYSTEM_TABLE *sys_table = NULL;

//////////////////// DBG ///////////////////////////

void print_key(){
    EFI_INPUT_KEY key;
    CHAR16 buffx[0xff];
    while (sys_table->ConIn->ReadKeyStroke(sys_table->ConIn, &key) != EFI_SUCCESS);

    print(L"Unicode CHAR: ");
    ptr_to_hex((void *)key.UnicodeChar, buffx);
    puts(buffx);
    print(L"Scan Code: ");
    ptr_to_hex((void *)key.ScanCode, buffx);
    puts(buffx);
}

void debug_infos(){
    CHAR16 gbuf[0xff];

    // some DBG infos
    print(L"Entry Point: ");
    ptr_to_hex((void *) efi_main, gbuf);
    puts(gbuf);
    print(L"General IO: ");
    ptr_to_hex((void *) &general_io, gbuf);
    puts(gbuf);
    print(L"sys_table: ");
    ptr_to_hex((void *) sys_table, gbuf);
    puts(gbuf);
    print(L"shell: ");
    ptr_to_hex((void *) shell, gbuf);
    puts(gbuf);
}
//////////////////// DBG ///////////////////////////


EFI_STATUS EFIAPI efi_main(EFI_HANDLE ImageHandler, EFI_SYSTEM_TABLE *SystemTable){
    (void) ImageHandler;
    sys_table = SystemTable;
    CHAR16	gbuf[0xff];

    sys_table->ConOut->Reset(sys_table->ConOut, TRUE);
    init();
    debug_infos();
    
    bool logstatus = login();
    while (logstatus != true){
	puts(L"Login failed, try again.\r\n\r\n");
	logstatus = login();
    }
    puts(L"Login succeeded, welcome home.");
    shell();

    syscalltable.exit(EfiResetShutdown, EFI_SUCCESS, 0, NULL);

    return EFI_SUCCESS;
}

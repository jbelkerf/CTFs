#include "../inc/burg.h"

int16_t strcmp(CHAR16 *a, CHAR16 *b){
    uint64_t i = 0;
    while (a[i] == b[i] && a[i] != L'\0' && b[i] != L'\0'){
	i++;
    }
    return ((int16_t)(a[i] - b[i]));
}

void strlcpy(CHAR16 *dst, CHAR16 *src, uint64_t n){
    uint64_t i = 0;
    while(i < n){
	*(dst + i) = *(src + i);
	i++;
    }
    *(dst + i) = L'\x00';
}

uint64_t strlen(CHAR16 *s){
    uint64_t i = 0;
    while (s[i] != L'\x00'){
	i++;
    }
    return (i);
}

void *memcpy(void *dst, void *src, uint64_t n){
    uint64_t i = 0;
    while(i < n){
	// copying byte by byte
	*((char *) dst + i) = *((char *) src + i);
	i++;
    }
    return (dst);
}

void *memset(void *s, char c, uint64_t n){
    uint64_t i = 0;
    while (i < n){
	*((char *)s + i) = c;
	i++;
    }
    return s;
}

VOID ptr_to_hex(VOID *ptr, CHAR16 *out) {
    static const CHAR16 hexChars[] = L"0123456789ABCDEF";

    UINTN value = (UINTN)ptr;
    UINTN nibbles = sizeof(UINTN) * 2;

    out[0] = L'0';
    out[1] = L'x';

    for (UINTN i = 0; i < nibbles; i++) {
        UINTN shift = (nibbles - 1 - i) * 4;
        UINTN nibble = (value >> shift) & 0xF;
        out[2 + i] = hexChars[nibble];
    }

    out[2 + nibbles] = L'\0';
}

void uint_to_str(UINTN value, CHAR16 *buffer) {
    CHAR16 *p = buffer;

    if (value == 0) {
        *p++ = L'0';
        *p = L'\0';
        return;
    }

    UINTN temp = value;
    UINTN div = 1;
    while (temp >= 10) {
        temp /= 10;
        div *= 10;
    }

    while (div > 0) {
        *p++ = L'0' + (value / div);
        value %= div;
        div /= 10;
    }
    *p = L'\0';
}
